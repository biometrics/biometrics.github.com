The probe and gallery images of Tamerlan and Dzhochar Tsarnaev used in
www.openbiometrics.org/papers/klontz2013case.pdf